class VariablenAendernIhreWerte {
	public static void main(String [] ignored) {
		int number = 1;
		System.out.println(number);
		number = 1;
		System.out.println(number);
		number = 2;
		System.out.println(number);
		number = 3;
		System.out.println(number);
		number = 1;
		System.out.println(number);
		number = 17;
		System.out.println(number);
	}
}