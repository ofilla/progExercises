class Formatierung1 {public static void main
	(String [] ignored) {
	System.out.println(0); int zero = 0;
			System.out.println(zero);
		int one = 1;
		int whatsThis = zero;
			System.out.
		println(whatsThis);
	whatsThis = one;		System.out.println(whatsThis)
;}}