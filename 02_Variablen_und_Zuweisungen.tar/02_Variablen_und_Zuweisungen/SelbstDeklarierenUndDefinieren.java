class SelbstDeklarierenUndDefinieren {
	public static void main(String [] ignored) {
		// deklariere eine Variable "birnen"  vom Typ int
		
		// weise ihr den Wert drei zu

//		System.out.println("3 erwartet: " + birnen);
		// addiere f�nf zu dem Wert

//		System.out.println("8 erwartet: " + birnen);
		// deklariere eine Variable "aepfel" und weise ihr den Wert f�nf zu

//		System.out.println("5 erwartet: " + aepfel);
		// subtrahiere zwei von dem Wert

//		System.out.println("3 erwartet: " + aepfel);

		
	}
}
