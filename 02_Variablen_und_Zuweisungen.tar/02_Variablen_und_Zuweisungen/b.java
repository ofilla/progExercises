class b {
	public static void main(String [] i) {
		System.out.println(0);
		int a = 0;
		System.out.println(a);
		int b = 1;
		int c = a;
		System.out.println(c);
		c = b;
		System.out.println(c);
	}
}